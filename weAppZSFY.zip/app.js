//app.js
const Bmob = require('utils/bmob.js');

Bmob.initialize("1792ddc7735c77dfe0ae03d454488a78", "17290c2cd6b66d7b8095f13318411655");
App({
  version: '1.0',
  data: {
    basicInfo: "https://fyapi.sinyu1012.cn/test/BasicInfoServlet",
    getCookie: "https://fyapi.sinyu1012.cn/test/JWYzmServlet",
    loginUrl: "https://fyapi.sinyu1012.cn/test/LoginServlet",
    getJWInfoUrl: "https://fyapi.sinyu1012.cn/test/GetJWInfoServlet",
    bindUserUrl: "https://fyapi.sinyu1012.cn/test/MinipgBindUserServlet",
    openLogUrl: "https://fyapi.sinyu1012.cn/test/MinipgOpenLogServlet",
    isBindInfoUrl: "https://fyapi.sinyu1012.cn/test/IsBindUserServlet",
    updateCJUrl: "https://fyapi.sinyu1012.cn/test/Update_CJServlet",
    serachBookUrl: "https://fyapi.sinyu1012.cn/test/SerachBookServlet", 
    serachBookDetailUrl: "https://fyapi.sinyu1012.cn/test/SerachBookDetailServlet", 
    serachBookNextPageUrl: "https://fyapi.sinyu1012.cn/test/SerachBookNextPageServlet", 
    queryzaocao: "https://fyapi.sinyu1012.cn/test/QueryzaocaoServlet",
    queryDetailzaocao: "https://fyapi.sinyu1012.cn/test/QueryzaocaoDetailServlet",
    getTimetable: "https://fyapi.sinyu1012.cn/test/GetTimeTableServlet"   ,
    getTodayInfo: "https://fyapi.sinyu1012.cn/test/GetTodayInfoServlet"    ,
    unBindUserUrl: "https://fyapi.sinyu1012.cn/test/MiniPGUnBindServlet"  ,
    getScore: "https://fyapi.sinyu1012.cn/test/GetScoreServlet"
  },
  store: {},
  onLaunch: function () {
    var that = this
    //调用API从本地缓存中获取数据
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    that.setStore('isrefresh', 1);
    console.log(this.store)

    wx.setStorageSync('logs', logs)
    //获取openid
    wx.login({
      success: function (res) {
        if (res.code) {
          //发起网络请求
          console.log(res.code)
          Bmob.User.requestOpenId(res.code, {
            success: function (result) {
              wx.setStorage({
                key: 'openid',
                data: result.openid,
                success: function (s) {
                  console.log('异步保存成功openid:' + result.openid)
                }
              })
              console.log(result)
              //获取是否绑定信息
              wx.request({
                url: getApp().data.isBindInfoUrl,
                header: {
                  'content-type': 'application/x-www-form-urlencoded' // 默认值
                },
                method: "POST",
                data: {
                  openid: result.openid
                },
                success: function (res) {
                  console.log(res)
                  //缓存数据
                  wx.setStorage({
                    key: 'isBindFlag',
                    data: res.data.flag,
                    success: function (s) {
                      console.log('异步保存成功flag:' + res.data.flag)
                    }
                  })
                  if (res.data.flag == 1) {
                    that.setStore('name', res.data.name);
                    that.setStore('xh', res.data.xh);
                    that.setStore('bind',1);
                    wx.setStorage({
                      key: 'xh',
                      data: res.data.xh,
                      success: function (s) {
                        console.log('异步保存成功xh:' + res.data.xh)
                      }
                    })
                    wx.setStorage({
                      key: 'pwd',
                      data: res.data.pwd,
                      success: function (s) {
                        console.log('异步保存成功pwd:' + res.data.pwd)
                      }
                    })
                    wx.setStorage({
                      key: 'name',
                      data: res.data.name,
                      success: function (s) {
                        console.log('异步保存成功name:' + res.data.name)
                      }
                    })
                  }

                }
              })
            },
            error: function (error) {
              // Show the error message somewhere
              console.log("Error: " + error.code + " " + error.message);
            }
          });
        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
          common.showTip('获取用户登录态失败！', 'loading');
        }
      }
    });
   
    
  },
  getUserInfo: function (cb) {
    var that = this
    if (this.globalData.userInfo) {
      typeof cb == "function" && cb(this.globalData.userInfo)
    } else {
      //调用登录接口
      wx.login({
        success: function () {
          wx.getUserInfo({
            success: function (res) {
              that.globalData.userInfo = res.userInfo
              typeof cb == "function" && cb(that.globalData.userInfo)
              // 保存用户基本信息
              that.setStore('nickName', res.userInfo.nickName);
              that.setStore('avatarUrl', res.userInfo.avatarUrl);
              
            }
          })
        }
      })
    }
  },
  globalData: {
    userInfo: null
  },
  

  // 更新store和storage
  setStore: function (key, value) {
    if (!key) {
      return;
    }
    this.store[key] = value;
    wx.setStorage({
      key: key,
      data: value
    });
  }
})